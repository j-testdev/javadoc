package pruebalibreria;

	/** Clase de prueba de la biblioteca de clases libreria
	*/
public class PruebaLibreria{


	//Métodos
	/** Programa principal de prueba de la biblioteca libreria
	 *  @param args argumentos pasados a través del intérprete de órdenes (command line)
	*/
	public static void main(String[] args){
		throw new Error();
	}


}